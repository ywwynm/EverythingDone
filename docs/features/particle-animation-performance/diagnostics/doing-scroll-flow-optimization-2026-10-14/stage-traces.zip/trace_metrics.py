import json, pathlib, sys, numpy as np

def q(values):
    return [round(float(n), 3) for n in np.quantile(values, [.5,.9,1])] if len(values) else []

for path in pathlib.Path(sys.argv[1]).glob('*/*/beat-trace.json'):
    rows = json.loads(path.read_text())
    report = json.loads(path.with_name('report.json').read_text(encoding='utf-8'))
    events = report['events']
    submits = [e for e in events if e['event'] == 'particle_buffer_submitted']
    base = submits[0]['values']['submittedNanos'] - submits[0]['elapsedMs'] * 1e6
    scrolls = [e for e in events if e['event'] == 'doing_probe_scroll']
    # 各竖向拖动先排除前 150ms。
    windows = [(e['elapsedMs']+150, scrolls[i+1]['elapsedMs']) for i,e in enumerate(scrolls[:-1]) if e['values']['state'] == 1]
    def inside(t): return any(a <= (t-base)/1e6 <= b for a,b in windows)
    captures = np.array([r for r in rows if r[0] == 5 and inside(r[1])])
    images = np.array([r for r in rows if r[0] == 8 and inside(r[1])])
    requests = [r for r in rows if r[0] == 9 and inside(r[1])]
    print(path.parent.parent.name, path.parent.name, 'rows',len(rows),'capture',len(captures),'images',len(images),'blocked',sum(r[2] for r in requests),'requests',len(requests))
    if len(captures):
        print('record',q((captures[:,3]-captures[:,2])/1e6),'sync',q((captures[:,4]-captures[:,3])/1e6),'captureInterval',q(np.diff(captures[:,1])/1e6))
    if len(images):
        for i,name in [(2,'image'),(3,'fence'),(4,'main'),(5,'upload'),(6,'gate')]:
            print(name,q((images[:,i]-images[:,i-1])/1e6))
        print('total',q((images[:,6]-images[:,1])/1e6))
    active = [e for e in events if e['event']=='swipe_activated'][0]['elapsedMs']
    shown = [e for e in events if e['event']=='swipe_pixels_visible'][0]['elapsedMs']
    pumps = [r for r in rows if r[0]==1 and active<=(r[1]-base)/1e6<=shown]
    print('first',round(shown-active,2),'pumpMax',q([r[5]/1e6 for r in pumps]))
    print('flowStages',[(r[1],round((r[2]-base)/1e6-active,2),round((r[3]-r[2])/1e6,2)) for r in rows if r[0]==10 and active<=(r[2]-base)/1e6<=shown])
    print('flowInitialize',[(r[1],round((r[2]-base)/1e6-active,2),round((r[3]-r[2])/1e6,2)) for r in rows if r[0]==11 and active<=(r[2]-base)/1e6<=shown])
    print([(e['event'],round(e['elapsedMs']-active,2),e['values']) for e in events if active<=e['elapsedMs']<=shown and e['event'] not in ('particle_buffer_submitted','particle_presentation_decision','swipe_motion')])
