import collections,hashlib,json,pathlib,re,statistics,sys,zipfile
ROOT=pathlib.Path(__file__).resolve().parent
CHECKS=pathlib.Path('docs/features/particle-animation-performance/checks').resolve()
sys.path.insert(0,str(CHECKS))
from analyze_doing_refresh_rate import distribution
from analyze_doing_real_checklist import aggregate
OUT=pathlib.Path('docs/features/particle-animation-performance/diagnostics/doing-real-checklist-scroll-2026-10-14')
OUT.mkdir(parents=True,exist_ok=True)

def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')

summary={};manifest=[];validation=[]
batches=[('baseline','analysis.json'),('contact-compare','analysis.json'),('trace','analysis.json'),
         ('fling','fling-analysis.json'),('fling-checklist','fling-analysis.json'),('fling-video','fling-analysis.json'),
         ('fling-trace','analysis.json')]
with zipfile.ZipFile(OUT/'reports.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for batch,analysis in batches:
  folder=ROOT/batch
  if not (folder/analysis).exists():continue
  rows=json.loads((folder/analysis).read_text(encoding='utf-8'))
  save(OUT/(batch+'-analysis.json'),rows)
  summary[batch]={}
  for device in ('samsung','meizu'):
   runs=[r for r in rows if r['device']==device]
   if batch.endswith('trace'):summary[batch][device]=runs;continue
   intervals=[s for r in runs for s in r['intervals']]
   summary[batch][device]={
    'runs':len(runs),'all':aggregate(intervals,'all'),
    'drag':aggregate([s for s in intervals if s['state']==1],'drag'),
    'fling':aggregate([s for s in intervals if s['state']==2],'fling'),
    'blocks':{b:aggregate([s for s in intervals if s['block']==b],b) for b in sorted({s['block'] for s in intervals})},
    'perRun':[{'run':r['run'],'all':r['aggregate']['fps'],'drag':r['drag']['fps'],'fling':r['fling']['fps']} for r in runs]}
  for p in sorted(folder.glob('*/*/report.json')):
   d=json.loads(p.read_text(encoding='utf-8'));es=d['events']
   assert d['droppedFrameEvents']==d['droppedLifecycleEvents']==0
   assert not any(any(w in e['event'] for w in ('failed','timeout','aborted')) for e in es)
   assert not any(e['event']=='swipe_activated' for e in es)
   instrument=(p.parent/'instrument.txt').read_text(encoding='utf-8')
   assert 'result=完成' in instrument and 'INSTRUMENTATION_CODE: 0' in instrument
   media={stage:json.loads((p.parent/f'media-{stage}.json').read_text()) for stage in ('before','after')}
   if media['before']['animated']:
    assert all(v['running'] for m in media.values() for v in m['animated'])
    assert media['before']['animated']!=media['after']['animated']
   temperatures=[];thermal=[]
   for stage in ('before','after'):
    temperatures+=re.findall(r'^\s*temperature:\s*(\d+)',(p.parent/f'battery-{stage}.txt').read_text(),re.M)[:1]
    thermal+=re.findall(r'Thermal Status:\s*(\d+)',(p.parent/f'thermal-{stage}.txt').read_text())
   validation.append({'batch':batch,'device':p.parent.parent.name,'run':p.parent.name,'build':d['metadata']['build'],
    'overflow':0,'clockTicks':sum(e['event']=='doing_probe_tick' for e in es),
    'swipeSnapshots':sum(e['event']=='swipe_capture_begin' for e in es),
    'media':media,'batteryC':[int(v)/10 for v in temperatures],'thermalStatus':thermal})
   for file in sorted(p.parent.iterdir()):
    if file.name in ['report.json','instrument.txt','geometry.json','timeline.json','beat-trace.json'] or file.name.endswith('-input.txt'):
     name=f'{batch}/{p.parent.parent.name}/{p.parent.name}/{file.name}'
     data=file.read_bytes();z.writestr(name,data)
     manifest.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 for file in [ROOT/'archive.py',*CHECKS.glob('*doing_real_checklist*.py'),CHECKS/'analyze_doing_fling.py',
              CHECKS/'analyze_doing_refresh_rate.py',CHECKS/'measure_doing_refresh_rate.py',
              pathlib.Path('docs/features/home-list-scroll-performance/device/HlsGestureInput.java'),
              pathlib.Path('tmp/home-list-scroll-20261009/driver/input.jar')]:
  z.write(file,'tools/'+file.name)
integrity={}
for device in ('samsung','meizu'):
 before=json.loads((ROOT/device/'integrity-before.json').read_text())
 after=json.loads((ROOT/device/'integrity-after.json').read_text())
 assert before==after,(device,before,after)
 integrity[device]={'before':before,'after':after,'unchanged':True}
save(OUT/'summary.json',summary);save(OUT/'manifest.json',manifest)
save(OUT/'validation.json',validation);save(OUT/'database-integrity.json',integrity)
print(json.dumps({'summary':summary,'archiveBytes':(OUT/'reports.zip').stat().st_size,
 'runs':len(validation),'unchanged':{k:v['unchanged'] for k,v in integrity.items()}},ensure_ascii=False))
